package com.cg.banking.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.bean.CustomerBean;
import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.OnlineBean;
import com.cg.banking.bean.CustomerBean;
import com.cg.banking.bean.PayeeDetailsBean;
import com.cg.banking.bean.ServiceTrackerBean;


public interface IBankingDao {
	
	
	public boolean checkLogin(UserBean bean) throws IOException, SQLException;

	public ArrayList<UserBean> changePassword(UserBean bean) throws IOException, SQLException;
	
	public int updatePassword(UserBean bean) throws SQLException, IOException;
	
	public int updateLock(UserBean bean) throws IOException, SQLException;

	public ArrayList<UserBean> getAccountId(UserBean bean) throws IOException, SQLException;

//home
	
	
	public ArrayList<OnlineBean> retriveDetails(int id, String startdate,String enddate) throws IOException, SQLException;
	ArrayList<OnlineBean> retriveLast(int id) throws SQLException, IOException;
//jyotsna
	
	ArrayList<CustomerBean> getAddr(long accountId);

	int changeAddr(CustomerBean bean);

	int changeMob(CustomerBean bean);

	int checkAccId(int accNo);
	
	
	//rohit
	
	//int requestforcheckbook(ServiceBean u) throws SQLException, IOException;

	int addDetails(ServiceTrackerBean u);
	
	
	//avinash
	

	public ArrayList<ServiceTrackerBean> fetchServiceDetailsByID(int serviceID);
	public ArrayList<ServiceTrackerBean> fetchServiceDetailsByAccountID(int accountID);
	public ArrayList<ServiceTrackerBean> statusOfAllRequest(int accountID);
	public ArrayList<ServiceTrackerBean> fetchServiceRequestID(int accountID);
	public ArrayList<ServiceTrackerBean> getRequestHistory(int accId);
	public ArrayList<CustomerBean> getAccountNumber(String pan);
	

	public int registerPayee(int accountID, int payeeAccountID, String payeeAccountName);
	public int transferFund(int transferFromAccount, int transferToAccount, int transferAmount);
	
	public ArrayList<PayeeDetailsBean> getPayeeDetails(int accountID);

	
	

}
