package com.cg.banking.bean;

public class CustomerBean {
	private long accNo;
	private String name;
	private String email;
	private String address;
	private String pancard;
	private long mobile;
	
	
	
	
	
	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	
	

	public CustomerBean(long accNo, String name, String email, String address,
			String pancard, long mobile) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.email = email;
		this.address = address;
		this.pancard = pancard;
		this.mobile = mobile;
	}
	
	

	public CustomerBean(long accNo) {
		super();
		this.accNo = accNo;
	}

	public CustomerBean() {
	}
	
	public CustomerBean(String address, long mobile) {
		super();
		this.address = address;
		this.mobile = mobile;
	}

	
	
	
	

}
