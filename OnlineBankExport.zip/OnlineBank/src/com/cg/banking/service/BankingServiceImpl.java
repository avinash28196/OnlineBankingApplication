package com.cg.banking.service;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.banking.bean.CustomerBean;
import com.cg.banking.bean.OnlineBean;
import com.cg.banking.bean.PayeeDetailsBean;
import com.cg.banking.bean.ServiceTrackerBean;
import com.cg.banking.bean.UserBean;
import com.cg.banking.dao.BankingDaoImpl;
import com.cg.banking.dao.IBankingDao;





public class BankingServiceImpl implements IBankingService {
	
	IBankingDao dao=null;

	

	@Override
	public boolean checkLogin(UserBean bean) throws IOException, SQLException {
		dao=new BankingDaoImpl();
		
		return dao.checkLogin(bean);
	}



	@Override
	public ArrayList<UserBean> changePassword(UserBean bean) throws IOException, SQLException {
		dao=new BankingDaoImpl();
		
		return dao.changePassword(bean);
	}



	@Override
	public boolean checkSecurityAnswer(String securityQuestion,
			String securityAnswer, String sAnswer) {
		
		if(securityAnswer.equals(sAnswer))
		{
			
			return true;
		}
		else
		{
			
			return false;
		}
		
	}



	@Override
	public int updatePassword(UserBean bean) throws SQLException, IOException {
		dao=new BankingDaoImpl();
		
		return dao.updatePassword(bean);
	}



	@Override
	public boolean checkPassword(String newPassword, String reEnterNewPassword) {
		
		if(newPassword.equals(reEnterNewPassword))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}



	@Override
	public int updateLock(UserBean bean) throws IOException, SQLException {
		dao=new BankingDaoImpl();
		
		return dao.updateLock(bean);
	}



	@Override
	public ArrayList<UserBean> getAccountId(UserBean bean) throws IOException, SQLException {
		
			dao=new BankingDaoImpl();
		
			return dao.getAccountId(bean);
		
	}



//bindu
	/*@Override
	public ArrayList<OnlineBean> retriveDetails(int id, Date startdate, Date enddate) throws SQLException, IOException {
		 ArrayList<OnlineBean> al=dao.retriveDetails(id,startdate,enddate);
		 return al;
	}*/

	@Override
	public ArrayList<OnlineBean> retriveDetails(int id, String startdate, String enddate) throws IOException, SQLException {
		 ArrayList<OnlineBean> al=dao.retriveDetails(id,startdate,enddate);
		 return al;
	}

	@Override
	public ArrayList<OnlineBean> retriveLast(int id) throws SQLException, IOException {
		ArrayList<OnlineBean> al=dao.retriveLast(id);
		 return al;
	}



//jyotsna
	
	
	@Override
	public ArrayList<CustomerBean> getAddr(long accountId) {
		return dao.getAddr(accountId);
	}
	@Override
	public int changeAddr(CustomerBean bean) {
		return dao.changeAddr(bean);

	}
	@Override
	public int changeMob(CustomerBean bean) {
		return dao.changeMob(bean);

	}
	@Override
	public boolean validatePhoneNo(String mob){
		String phonepattern="[7-9][0-9]{9}";
		if(Pattern.matches(phonepattern, mob))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter the valid Mobile number");
			return false;
		}
	}
	@Override
	public boolean validateAddress(String address) {
		String ptn="[a-zA-Z]{2,}";
		if(Pattern.matches(ptn, address))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter the valid Address");
			return false;
		}
	}
	@Override
	public boolean checkAccId(int accNo)
	{
			int res=dao.checkAccId(accNo);
			if(res==1)
			{
				return true;
			}
			else
			{
				return false;
			}
	}
	
	
	//rohit
	

	
	/*public int requestforcheckbook(ServiceBean u) throws SQLException, IOException {
		
		
		return dao.requestforcheckbook(u);
	}*/

	@Override
	public int addDetails(ServiceTrackerBean u) {
		
		return dao.addDetails(u);
	}



//avinash
	
	
	
	@Override
	public ArrayList<ServiceTrackerBean> fetchServiceDetailsByID(int serviceID) {
		dao = new BankingDaoImpl();
		return dao.fetchServiceDetailsByID(serviceID);
	}

	@Override
	public ArrayList<ServiceTrackerBean> fetchServiceDetailsByAccountID(int accountID) {
		dao = new BankingDaoImpl();
		return dao.fetchServiceDetailsByAccountID(accountID);
	}

	@Override
	public ArrayList<ServiceTrackerBean> statusOfAllRequest(int accountID) {
		dao = new BankingDaoImpl();
		return dao.statusOfAllRequest(accountID);
	}

	@Override
	public ArrayList<ServiceTrackerBean> fetchServiceRequestID(int accountID) {
		dao = new BankingDaoImpl();
		return dao.fetchServiceRequestID(accountID);
	}

	@Override
	public ArrayList<ServiceTrackerBean> getRequestHistory(int accId) {
		dao = new BankingDaoImpl();
		return dao.getRequestHistory(accId);
	}

	@Override
	public ArrayList<CustomerBean> getAccountNumber(String pan) {
		dao = new BankingDaoImpl();;
		return dao.getAccountNumber(pan);
	}

	

	@Override
	public int registerPayee(int accountID, int payeeAccountID, String payeeAccountName) {
		dao = new BankingDaoImpl();
		return dao.registerPayee(accountID,payeeAccountID,payeeAccountName);
	}

	@Override
	public int transferFund(int transferFromAccount, int transferToAccount, int transferAmount) {
		dao = new BankingDaoImpl();
		return dao.transferFund(transferFromAccount,transferToAccount,transferAmount);
	
	}

	@Override
	public ArrayList<PayeeDetailsBean> getPayeeDetails(int accountID) {
		dao = new BankingDaoImpl();
		return dao.getPayeeDetails(accountID);
	}



	



	


	

	

}
