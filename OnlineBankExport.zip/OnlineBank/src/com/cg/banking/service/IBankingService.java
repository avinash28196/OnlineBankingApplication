package com.cg.banking.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.bean.CustomerBean;
import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.OnlineBean;
import com.cg.banking.bean.PayeeDetailsBean;
import com.cg.banking.bean.ServiceTrackerBean;

public interface IBankingService {

	
	public boolean checkLogin(UserBean bean) throws IOException, SQLException;

	public ArrayList<UserBean> changePassword(UserBean bean) throws IOException, SQLException;

	

	

	public boolean checkSecurityAnswer(String securityQuestion,String securityAnswer, String sAnswer);
	
	
	public int updatePassword(UserBean bean) throws SQLException, IOException;

	public boolean checkPassword(String newPassword, String reEnterNewPassword);
	
	
	
	public int updateLock(UserBean bean) throws IOException, SQLException;

	public ArrayList<UserBean> getAccountId(UserBean bean) throws IOException, SQLException;
	
	
	
	//home
	
	ArrayList<OnlineBean> retriveDetails(int id, String startdate, String startdate2) throws IOException, SQLException;

	ArrayList<OnlineBean> retriveLast(int id) throws SQLException, IOException;
	
	//jyotsna
	
	ArrayList<CustomerBean> getAddr(long accountId);

	int changeAddr(CustomerBean bean);

	int changeMob(CustomerBean bean);

	boolean validatePhoneNo(String mob);

	boolean validateAddress(String address);

	boolean checkAccId(int accNo);
	
	
	//rohit
	
	//int requestforcheckbook(ServiceBean u) throws SQLException, IOException;

	int addDetails(ServiceTrackerBean u);
	
	//avinash
	
	ArrayList<ServiceTrackerBean> fetchServiceDetailsByID(int serviceID);
	ArrayList<ServiceTrackerBean> fetchServiceDetailsByAccountID(int accountID);
	ArrayList<ServiceTrackerBean> statusOfAllRequest(int accountID);
	ArrayList<ServiceTrackerBean> fetchServiceRequestID(int accountID);
	ArrayList<ServiceTrackerBean> getRequestHistory(int accId);
	
	ArrayList<CustomerBean> getAccountNumber(String pan);
	
	
	int registerPayee(int accountID, int payeeAccountID, String payeeAccountName);
	int transferFund(int transferFromAccount, int transferToAccount, int transferAmount);
	
	
	ArrayList<PayeeDetailsBean> getPayeeDetails(int accountID);

	
	
}
