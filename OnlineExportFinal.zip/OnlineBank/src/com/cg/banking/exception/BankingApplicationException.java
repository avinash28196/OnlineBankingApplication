package com.cg.banking.exception;

public class BankingApplicationException extends Exception {

	public BankingApplicationException(String msg)
	{
		super(msg);
	}
}
